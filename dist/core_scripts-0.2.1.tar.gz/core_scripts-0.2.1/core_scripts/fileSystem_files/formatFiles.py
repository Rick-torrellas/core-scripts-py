image = [
    "jpg",
    "png",
    "jpeg",
    "gif",
    "ico",
    "webp",
    "svg"
]