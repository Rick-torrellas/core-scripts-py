from compress_only_dirs import compress_all_dirs

def compress_all_dirs_in_list(lists):
    for dir in lists:
        compress_all_dirs(dir)