from core_commands.cmd.mkdir import mkdir # type: ignore
from sys import argv

if __name__ == "__main__":
    mkdir('./ostia')

def make_dir():
    pass