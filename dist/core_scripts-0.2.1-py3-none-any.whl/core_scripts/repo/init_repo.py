def init_repo(repo,opts):
    """
        crea el repositorio en github, y inicia el reopsitio con git, hace un commit y lo publica a github.
    """
    # Verifica que el repositorio no este vacio, ya que no podria hacer el primer commit.
    
    pass