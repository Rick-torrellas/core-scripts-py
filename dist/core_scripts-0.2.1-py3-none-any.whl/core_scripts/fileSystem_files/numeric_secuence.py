"""
    Crea una secuencia numerica en todos los archivos de una ruta, ya sean carpetas o archivos.
"""

